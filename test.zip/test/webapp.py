from flask import Flask, render_template, request,flash,redirect,url_for
import pandas,pymysql,sys
import numpy as np
sys.stdout.flush()
f1 = 'data.csv'

app = Flask(__name__)

app.config['SECRET_KEY'] = 'vidyashri'


def read_files(f1):
    df = pandas.read_csv(f1)
    df.index = df.index + 1

    df2 = df[['givenName', 'middleName', 'surname']].copy()
    return df2


@app.route('/')
def index():
    return render_template('index.html')
@app.route('/details', methods=['POST'])


def details():
    name = request.form['name']
    df2=read_files(f1)
    df1 = (df2[df2['givenName'].str.contains(name, na=False, case=False)])

    df3 = (df2[df2['middleName'].str.contains(name, na=False,case=False)])
    df4 = (df2[df2['surname'].str.contains(name, na=False,case=False)])
    newd = pandas.concat([df1, df3]).drop_duplicates().reset_index(drop=True)
    final1 = pandas.concat([newd, df4]).drop_duplicates().reset_index(drop=True)
    final=final1.fillna('-')
    final["Rank"] = np.nan
    final.index=final.index+1
    for index, row in final.iterrows():
        if name in row:
                final.at[index, 'Rank'] = 10
        else:
                final.at[index, 'Rank'] = 100
    return render_template('datatable.html', tables=[final.to_html(classes='data')], titles=final.columns.values)


if __name__ == '__main__':
    app.run(debug=True)

